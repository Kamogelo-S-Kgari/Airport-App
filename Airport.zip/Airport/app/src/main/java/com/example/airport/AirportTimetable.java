package com.example.airport;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AirportTimetable extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_airport_timetable);
    }



}
